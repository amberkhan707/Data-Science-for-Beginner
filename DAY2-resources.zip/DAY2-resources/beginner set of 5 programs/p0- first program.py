# my first program 
print('Hello Python')
print("Compute 25 x 30: " , 25*30)

print ("Great Job")

value = int(input("Enter a integer value"))
print("Square of the given value is " , value*value)


